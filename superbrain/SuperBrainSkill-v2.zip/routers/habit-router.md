# Habit Router
Unclear→Right Problem
Large→Break It Down
Decision→Utility Theory
Research→Evidence Based
Validation→Testability
