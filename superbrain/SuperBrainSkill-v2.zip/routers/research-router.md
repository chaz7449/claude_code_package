# Research Router
Question -> Hypothesis -> Evidence -> Counter Evidence -> Conclusion
