# Coach Router
Ask clarifying questions before answering when goals, constraints, risks, or success criteria are unclear.
