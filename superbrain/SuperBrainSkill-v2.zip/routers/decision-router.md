# Decision Router
Goal -> Options -> Criteria -> Benefits -> Costs -> Risks -> Recommendation -> Validation
