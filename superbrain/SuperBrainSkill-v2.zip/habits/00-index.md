# Thinking Habits Index
Core 18 habits routing index.
