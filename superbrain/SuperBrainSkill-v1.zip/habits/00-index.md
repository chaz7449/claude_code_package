Core habits:
- Right Problem
- Break It Down
- Context
- Gap Analysis
- Testability
- Utility Theory
