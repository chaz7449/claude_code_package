# Coach Router

If request is unclear:
- Ask clarifying questions

If problem is large:
- Use Break It Down

If decision:
- Use Utility Theory

If validation:
- Use Testability
