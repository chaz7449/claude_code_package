# Claude Code 思考習慣書架

## 這包是什麼

這是一套給 Claude Code 使用的個人 AI 超級大腦架構：

- `CLAUDE.md`：總指揮手冊
- `thinking-habits/00-index.md`：76 個思考習慣目錄
- `thinking-habits/01-core-18.md`：最常用 18 個
- `thinking-habits/full-76/`：76 個完整思考習慣獨立檔
- `workflows/`：常用工作流程
- `outputs/`：輸出資料夾

## 怎麼用

把這包解壓縮後，將裡面的檔案整包放進你的 Claude Code 專案資料夾。

如果你的專案已經有 `CLAUDE.md`，請先備份，再把這包的內容合併進去。
