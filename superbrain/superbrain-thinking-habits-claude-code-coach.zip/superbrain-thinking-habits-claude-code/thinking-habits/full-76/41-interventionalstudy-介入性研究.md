## 41. 介入性研究 {#interventionalstudy}

### 後設資料

- **標籤：** `#介入性研究(#interventionalstudy)`
- **核心能力：** 創意思考

### 一句話精華

> 要真的把因與果釘住，有時候你得親自跑那場實驗。

### 定義

嚴格意義下的實驗，至少有一個自變數被刻意操弄或挑選，至少有一個應變數用來讀出該操弄的後果。其機制是把樣本指派到處理條件（也就是介入），同時盡可能壓住其他影響的作用。要結論「該處理在做因果工作」，必須把那些外來影響、以及任何可能撼動結果的因素都壓住。把實驗與觀察性研究區分開的就是這一點：實驗一定涉及介入。

### 何時適用

當評論或設計一個介入性研究時，使用 `#介入性研究(#interventionalstudy)`。

### 自我學習問題

1. 準實驗研究與隨機對照試驗有何不同？如何選擇？
2. 設計介入性研究時，可以採取哪些措施降低偏誤與混淆變數的影響？
3. 如何確保研究設計真的能檢驗該假說？

### 反思檢查清單

- 你是否深入說明為何介入性研究是這裡最合適的選擇？
- 你是否詳細描述該研究，並以證據（例如類似研究所用方法）支持設計選擇？
- 你是否考量了（或至少點名）外來變數與認知偏誤？
- 你是否透過列出強項與限制，評估了該設計？

### 常見坑

- 研究類型被誤分類。
- 研究描述過於淺薄。
- 設計實際上無法檢驗該假說。
- 設計選擇沒有被說明或解釋清楚。

### 關鍵資源

- Lesh（2015）「Observational vs. experimental study」（YouTube）：兩種設計關鍵差異的短片。
- Lacey（1997）「Experimental design」，*Statistics 101–103: Summaries of Topics*（Yale University）：實驗設計的精要綜述，含發展或評論實驗時需考量的面向。
- Sibbald & Roland（1998）「Understanding controlled trials: why are randomised controlled trials important?」，*British Medical Journal*, 316(7126), 201：對 RCT 元素、適用範圍與限制的一頁綜覽。
- Harris 等人（2004）「The use and interpretation of quasi-experimental studies in infectious diseases」，*Clinical Infectious Diseases*, 38(11), 1586–1591：臨床研究中準實驗設計的回顧。
- Kosslyn & Rosenberg（2001）「QALMRI instructions」：閱讀與書寫實驗報告的結構化框架。

---
