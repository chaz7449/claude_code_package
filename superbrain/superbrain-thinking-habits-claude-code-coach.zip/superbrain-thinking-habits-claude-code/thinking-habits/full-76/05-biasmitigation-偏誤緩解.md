## 5. 偏誤緩解 {#biasmitigation}

### 後設資料

- **標籤：** `#偏誤緩解(#biasmitigation)`
- **核心能力：** 批判思考

### 一句話精華

> 看出偏誤還不夠——還得真的做點什麼，把它的影響壓下來。

### 定義

偏誤會把相關資訊擋在決策視野之外，從而影響判斷品質。降低偏誤的影響是兩步驟的動作：先建立對眼前具體偏誤的覺察，再設計一道流程或規則，限制它在此情境下能扭曲決策的程度。有些偏誤一旦被認出來就能繞過去，但多數偏誤必須靠刻意流程處理——檢核表、結構化比較、減偏提示、判斷脫鉤——因為單純的「覺察」很少能蓋過它在底層的拉力。對應偏誤的捷思在這裡有用，但必須對應到那項偏誤本身才有意義。

### 何時適用

在以下情況使用 `#偏誤緩解(#biasmitigation)`：

- 提出一個或多個策略來降低認知偏誤的影響。
- 評估某項既有的偏誤緩解策略是否真的有效。

### 自我學習問題

1. 什麼是 GI Joe 謬誤？
2. 如何降低確認偏誤？
3. 有哪些降低情緒偏誤的方法？
4. 有哪些降低注意力偏誤的方法？
5. 有哪些降低記憶偏誤的方法？
6. 何時偏誤的緩解才真的必要？
7. 怎麼決定該用 `#偏誤檢驗(#biasidentification)`、`#偏誤緩解(#biasmitigation)`，還是 `#詮釋視角(#interpretivelens)`？

### 反思檢查清單

- 你是否提出了一個與該特定偏誤相符的緩解策略？
- 你是否說明了緩解策略與其針對的偏誤之間的作用機制？
- 你是否評估了該策略有多強，以及它的限制？

### 常見坑

- 緩解的目標其實不是認知偏誤（例如抽樣偏誤）。
- 提出了緩解策略，卻沒解釋為什麼這套策略有效的機制。
- 作品聲稱「消除」偏誤。認知偏誤可以被降低，但無法真的消除。
- 討論緩解策略時沒指明所對應的具體偏誤。

### 關鍵資源

- Santos「Cognitive biases: the GI Joe fallacy」（Khan Academy）：四分鐘短片，說明為什麼光是有覺察並不能修復偏誤判斷，因此才需要 `#偏誤緩解(#biasmitigation)`。
- Lerner, Li, Valdesolo, & Kassam（2015）「Emotion and decision making」，*Annual Review of Psychology*, 66(1), 799–823：前半描述情緒偏誤如何形塑決策；後半（約第八節）討論緩解策略，包括已被研究證實偏弱的策略。
- Kassin, Dror, & Kukucka（2013）「The forensic confirmation bias: problems, perspectives, and proposed solutions」，*Journal of Applied Research in Memory and Cognition*, 2(1), 42–52。

---
