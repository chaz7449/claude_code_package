## 55. 權力動態 {#powerdynamics}

### 後設資料

- **標籤：** `#權力動態(#powerdynamics)`
- **核心能力：** 互動思考

### 一句話精華

> 權力的來源遠不只正式權威；在情境裡讀出正在作用的來源，才是真正能拉開差距的地方。

### 定義

廣義來說，權力是「讓他人違反預設去行動」的能力。它與正式權威或武力威脅的聯結很強，但那只是其中一片：影響力也可以來自對資訊的存取、來自關係、來自專業、來自魅力。指認情境中真正在作用的權力來源，既能讓人有意識地行使影響力，也能更準確地讀懂團體動態與社會情境。

### 何時適用

在以下情況使用 `#權力動態(#powerdynamics)`：

- 檢視人如何彼此影響。
- 思考一個系統、團體或組織中權力的來源與分布。
- 觀察不同形式的權力如何運作、又能如何被使用。
- 用對權力來源的理解來精修自己的影響力。
- 提出對權力來源的細膩解讀，作為社會批判的一部分。

### 自我學習問題

1. 個人層次上的權力來源有哪些例子？
2. Lukes 所提的三張權力面孔有哪些例子？
3. 正式與非正式權力來源有什麼差別？通常哪一個影響較大？
4. 在各種情境下，哪種權力較可能足以發揮？
5. 什麼是壓迫或支配（domination）？

### 反思檢查清單

- 你是否考量了不同層次上的多種權力類型？
- 你是否說明在該情境下相關的權力來源以及它們如何運作？
- 你是否說明權力的源頭，以及它如何被維持（或如何結束）？
- 你是否呈現不同類型權力的效應？
- 你是否用證據支撐你對權力來源與效應的解釋與分析？
- 你是否比較多種運用權力的方式，以支持你對「最有效策略」的選擇？
- 你是否調查權力的承受者，以及他們的特徵或關係如何要求特定形式的權力？
- 你是否說明某種特定權力形式的施力點，以及對團體預期的效應？

### 關鍵資源

- Moon（2019）「Power in global governance: an expanded typology from global health」，*Globalization and Health*, 15(1), 74：在更廣的結構脈絡下權力如何運作的例子，含治理機構中權力的綜合分類。
- McCammon（2018）「Domination」，*Stanford Encyclopedia of Philosophy*：把支配當作一種權力行使來分析；注意「支配可以源自影響他人之能力，而不只是主動行使權力」這個觀點。
- Rebolledo（2023）「Iris Marion Young's five faces of oppression」（Critical Legal Thinking）：Young 對壓迫的五個面向——剝削、邊緣化、無權、文化帝國主義、暴力——的概覽，及其在區分壓迫與支配上的用法。
- Sardo（2020）「Pols 101 Class 23: The three faces of power」（YouTube）：Lukes 的三維權力理論及 Gaventa 的延伸的講座。
- Tappan（2006）「Reframing internalized oppression and internalized domination: from the psychological to the sociocultural」，*Teachers College Record*, 108, 2115–2144。

---
