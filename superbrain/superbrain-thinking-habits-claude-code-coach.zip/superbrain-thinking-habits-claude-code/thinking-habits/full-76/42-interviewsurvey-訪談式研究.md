## 42. 訪談式研究 {#interviewsurvey}

### 後設資料

- **標籤：** `#訪談式研究(#interviewsurvey)`
- **核心能力：** 創意思考

### 一句話精華

> 訪談對少數人挖深；問卷對多數人鋪廣——挑與問題相符的那個。

### 定義

大量第一手研究，尤其在社會科學與公衛領域，仰賴對人類受測者的訪談與問卷。相關方法學文獻已累積出最佳實踐。訪談可以結構化（每個人問一樣的問題），或開放式（引導對話）。問卷需避免引導性問題，並謹慎控制回應選項如何形塑答案。網路型訪談與問卷有自身的挑戰，包括驗證受測者身份。

### 何時適用

在以下情況使用 `#訪談式研究(#interviewsurvey)`：

- 為研究目的設計問卷或訪談。
- 評論他人設計的問卷或訪談。

### 自我學習問題

1. 設計問卷有哪些不同取徑？
2. 各取徑各自的優缺點是什麼？
3. 在混合方法設計中，並行設計與序貫設計有何不同？
4. 進行問卷研究的一般步驟是什麼？
5. 在設計問卷取徑本身時，要考慮哪些事？
6. 評估問卷題目的準則是什麼？
7. 什麼是前言（preamble）？
8. 什麼是篩選題（screening question）？
9. 好題目設計的原則是什麼？
10. 適用於問卷的倫理原則有哪些？
11. 訪談的主要類型有哪些？
12. 如何處理質性資料？
13. 什麼是前測（pretest）？
14. 機構審查委員會（IRB）有什麼幫助？

### 反思檢查清單

- 你是否定義了目標母體與抽樣方法？
- 你是否說明篩選題背後的理由？
- 你是否做了前測？
- 你是否規劃了合適的方法來分析問卷或訪談資料？
- 你是否把結果回扣到研究問題？
- 你是否討論問卷或訪談的強項與限制？
- 你是否針對限制提出解方？

### 常見坑

- 問卷或訪談違反研究倫理。
- 目標母體與研究問題不符。
- 問卷或訪談未做前測。
- 題目有明顯設計缺陷（引導性問題、措辭含糊）。
- 所選取徑（例如混合方法設計）不適合或沒解釋清楚。
- 結果被錯誤解讀或只停在表面。
- 結果未回扣到研究問題。
- 沒在附錄中附上問卷副本。

### 關鍵資源

- ACET（2013）「Selecting an evaluation: qualitative, quantitative, and mixed-method approaches」：主要問卷取徑及其優缺點的短文。
- Thayer-Hart 等人（2010）「Survey fundamentals: a guide to designing and implementing surveys」（Office of Quality Improvement, University of Wisconsin–Madison）：問卷面向的主要參考。
- Gill, Stewart, Treasure, Chadwick（2008）「Methods of data collection in qualitative research: interviews and focus groups」，*British Dental Journal*, 204(6), 291–295：訪談面向的主要參考，含何時用焦點團體取代個別訪談。
- Bhandari（2020）「Ordinal data: examples, collection, and analysis」（Scribbr）：問卷常見的順序資料的統計方法。

---
