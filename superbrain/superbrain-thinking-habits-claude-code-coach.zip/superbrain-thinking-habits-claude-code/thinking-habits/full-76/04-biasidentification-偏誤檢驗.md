## 4. 偏誤檢驗 {#biasidentification}

### 後設資料

- **標籤：** `#偏誤檢驗(#biasidentification)`
- **核心能力：** 批判思考

### 一句話精華

> 對人類認知會以哪些可預測方式出錯，保有一套可用的覺察。

### 定義

我們對世界的理解，是透過注意什麼、聚焦什麼、記住什麼這幾道濾鏡所形成的。認知偏誤與情緒狀態會悄悄塑造這套濾鏡，進而以可辨識的方式影響記憶與決策。人們會習慣性地過濾掉與既有信念衝突但其實有用的資訊；偏好搜尋確認原本想法的證據；把模糊資訊讀成支持自己原本觀點的方向。捷思（快速、有效率的經驗法則）讓問題解決變得可行，但用到它們原本不適用的情境時，會產生系統性錯誤。應用 `#偏誤檢驗(#biasidentification)` 就是明確指認當下在作用的具體偏誤，並說明它如何解釋眼前被分析的行為或決策。

### 何時適用

在以下情況使用 `#偏誤檢驗(#biasidentification)`：

- 用一個或多個偏誤來解釋某種心理行為或決策。
- 分析特定認知偏誤與捷思之間的關係。
- 透過認知偏誤的視角反思自己的行為。

### 自我學習問題

1. 什麼樣的東西算是認知偏誤？
2. 認知偏誤的主要類別有哪些？
3. 自下而上（bottom-up）與自上而下（top-down）的注意力偏誤有何不同？
4. 內在情緒（integral emotions）與外部情緒（incidental emotions）有何不同？
5. 記憶偏誤何時會發生？
6. 這個思考習慣涵蓋所有類型的偏誤嗎？
7. 怎麼決定該用 `#偏誤檢驗(#biasidentification)`、`#偏誤緩解(#biasmitigation)`，還是 `#詮釋視角(#interpretivelens)`？

### 反思檢查清單

- 你是否指認了相關的具體認知偏誤？
- 你是否描述了偏誤與偏誤之間、或偏誤與捷思之間的交互作用？
- 你是否清楚說明偏誤如何產生眼前這個特定的決策或行為？

### 常見坑

- 引用的是錯誤類型的偏誤，或所指的偏誤其實與情境無關。
- 偏誤名稱正確，但偏誤如何造成該特定行為的連結沒被講清楚。
- 為單一情境列出多個偏誤，卻沒有分析偏誤之間的互動。
- 把非認知偏誤（例如抽樣偏誤）當成認知偏誤處理。

### 關鍵資源

- Behavioral Science Solutions「Behavioral Science Concepts」：可搜尋的捷思與偏誤迷你百科，每個詞條配一篇短文。
- Bennett（2014）「Confirmation bias」（YouTube）：五分鐘附日常案例的確認偏誤概覽。
- Innocence Project（2018）「Human factors in wrongful convictions: memory malleability」（YouTube）：記憶偏誤的研究以及其對證人證詞的影響。
- Le Cunff「Memory bias: how selective recall can impact your memories」（Ness Labs）：拆解記憶偏誤的類型，並討論其適應性功能。
- Lerner, Li, Valdesolo, & Kassam（2015）「Emotion and decision making」，*Annual Review of Psychology*, 66(1), 799–823：討論外部情緒與內在情緒，以及評價傾向架構（Appraisal Tendency Framework）。注意「效價」（valence）只是把情緒分成正向或負向；本文的關鍵主張是即使效價相同的兩種情緒（例如恐懼與憤怒），也會帶來不同的行為後果。
- Yue「Divided attention, selective attention, inattentional blindness, and change blindness」（Khan Academy）。

---
