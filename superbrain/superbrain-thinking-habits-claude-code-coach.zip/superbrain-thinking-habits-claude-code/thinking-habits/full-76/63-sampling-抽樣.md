## 63. 抽樣 {#sampling}

### 後設資料

- **標籤：** `#抽樣(#sampling)`
- **核心能力：** 創意思考

### 一句話精華

> 不好的樣本產生「看起來像答案」的結果，但實際上只是樣本本身的描述。

### 定義

許多研究會測量樣本特徵，以估計對應母體的特徵（例如測量一群七年級男孩以估計整體七年級男孩的平均身高）。這個動作內建的風險是：任何樣本都可能誤呈現目標母體中特徵的分布。合適的抽樣方法與對「樣本可推廣性」的誠實評估，因此是研究設計的一部分——不是可選的附加。

### 何時適用

在以下情況使用 `#抽樣(#sampling)`：

- 為研究設計挑選抽樣方法。
- 構造多階段抽樣方法。
- 評論既有研究的抽樣方法。

### 自我學習問題

1. 抽樣方法的主要類型有哪些？
2. 評估一個樣本時，哪些準則重要？
3. 抽樣中常見的挑戰有哪些？
4. 什麼是多階段抽樣？
5. 什麼是實驗單位（experimental unit）？
6. 什麼是偽複製（pseudoreplication）？
7. 機率抽樣與非機率抽樣有什麼差別？
8. 什麼是抽樣框架（sampling frame）？
9. 什麼是抽樣偏誤（sampling bias）？

### 反思檢查清單

- 你是否為該研究情境選了最合適的抽樣方法？
- 你是否考慮過多階段抽樣？
- 你是否清楚定義母體、實驗單位與樣本？
- 你是否識別抽樣方法可能的限制？
- 你是否討論該樣本有多具代表性？

### 常見坑

- 抽樣設計有明顯缺陷——在沒有抽樣框架下使用分層抽樣、使用不合倫理的抽樣方法、對樣本數沒給出理由或討論。
- 沒就抽樣方法的強項與限制提出理由。
- 設計明顯是偽複製，但沒嘗試緩解該問題。

### 關鍵資源

- Dr Nic's Maths and Stats（2012）「Sampling: simple random, convenience, systematic, cluster, stratified」（YouTube）：抽樣方法的五分鐘入門。
- Penn State Eberly College of Science「Simple random sampling and other sampling methods」（STAT 100）：常見抽樣方法的範例與討論。
- Reinhart（2015）「Pseudoreplication: choose your data wisely」，*Statistics Done Wrong*（No Starch Press）。

---
