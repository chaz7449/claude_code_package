package agent

import (
	"path/filepath"
	"strings"
	"testing"

	"github.com/yetone/magpie/internal/edit"
	"github.com/yetone/magpie/internal/provider"
)

// A tier, or the subagents, given a model picked from the list keeps it
// when the main model moves, though the pick is the main model itself or
// the model the tier would follow on it, picked in magpie with the main
// model moved in magpie or in Claude Code's /model (#2654, ypli0629: a
// sonnet tier given K2.8 Preview, the main model, read as "Same as main
// model", and the move to GLM-6 took it along). "Same as main model"
// picked afterwards has it follow again.
func TestClaudeTierPickedAsTheMainModelStays(t *testing.T) {
	type pick struct{ main, key, model string }
	var picks []pick
	for _, main := range []string{"oa/k2.8-preview", "anth/claude-opus-5-5"} {
		for _, k := range append(append([]string{}, claudeTiers...), "subagent") {
			picks = append(picks, pick{main, k, main})
		}
	}
	// haiku on a Claude main model follows its Haiku: that Haiku picked
	picks = append(picks, pick{"anth/claude-opus-5-5", "haiku", "anth/claude-haiku-4-5"})
	for _, p := range picks {
		for _, via := range []string{"magpie", "/model"} {
			t.Run(p.main+"/"+p.key+"="+p.model+"/"+via, func(t *testing.T) {
				home, _ := codexHome(t, "", "")
				a := claude(home)
				if err := provider.Save(provider.Provider{ID: "anth", Name: "Anthropic", Chat: "https://api.anthropic.com/v1", Key: "k",
					Models: []string{"claude-opus-5-5", "claude-haiku-4-5"}}); err != nil {
					t.Fatal(err)
				}
				if err := provider.Save(provider.Provider{ID: "oa", Name: "OA", Chat: "https://oa.example/v1", Key: "k",
					Models: []string{"k2.8-preview", "glm-6"}}); err != nil {
					t.Fatal(err)
				}
				path := filepath.Join(home, ".claude", "settings.json")
				bare := func(s string) string { return strings.TrimSuffix(s, "[1m]") }
				envKey := "CLAUDE_CODE_SUBAGENT_MODEL"
				if p.key != "subagent" {
					envKey = tierEnv(p.key)
				}
				written := func() string { m, _ := edit.GetJSON(path, "env."+envKey); return bare(m) }
				main := func(m string) {
					t.Helper()
					if via == "magpie" {
						if err := a.Apply("model", m); err != nil {
							t.Fatal(err)
						}
					} else {
						if err := edit.SetJSON(path, edit.KV{Path: "model", Value: m}); err != nil {
							t.Fatal(err)
						}
						if err := a.Follow(); err != nil {
							t.Fatal(err)
						}
					}
				}
				if err := a.Apply("model", p.main); err != nil {
					t.Fatal(err)
				}
				if err := a.Apply(p.key, p.model); err != nil {
					t.Fatal(err)
				}
				if v := a.Values(); bare(v[p.key]) != p.model {
					t.Fatalf("%s picked as %s reads %q, as if it followed the main model\n%s", p.key, p.model, v[p.key], readFile(path))
				}
				if written() != p.model {
					t.Fatalf("%s picked as %s is written %q\n%s", p.key, p.model, written(), readFile(path))
				}
				main("oa/glm-6")
				if written() != p.model {
					t.Fatalf("main model moved: %s is %q, not its own %s\n%s", p.key, written(), p.model, readFile(path))
				}
				if v := a.Values(); bare(v[p.key]) != p.model {
					t.Fatalf("main model moved: %s reads %q, not its own %s", p.key, v[p.key], p.model)
				}

				// "Same as main model": it follows again
				if err := a.Apply(p.key, ""); err != nil {
					t.Fatal(err)
				}
				main("oa/k2.8-preview")
				if v := a.Values(); v[p.key] != "" {
					t.Fatalf("same as main model: %s reads %q\n%s", p.key, v[p.key], readFile(path))
				}
				if w := written(); w == p.model && p.model != "oa/k2.8-preview" || w == "oa/glm-6" {
					t.Fatalf("same as main model: %s is still %q\n%s", p.key, w, readFile(path))
				}
			})
		}
	}
}
